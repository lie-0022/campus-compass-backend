---
name: "🔍 일반 이슈"
about: "작업 단위 이슈 템플릿"
title: "[Task] "
labels: ["todo"]
assignees: []
---
<!-- #이슈 번호를 매겨주세요 (보통은 PR 본문에서 resolves를 사용합니다) -->
- resolves #number
### 🔍 설명
-

### 🔥 할 일
-

### ⏰ 예상 시간
-

### 🐴 할 말
-
