package com.campuscompass.backend.user.dto;

import lombok.Getter;

@Getter
public class RefreshRequest {
    private String refreshToken;
}