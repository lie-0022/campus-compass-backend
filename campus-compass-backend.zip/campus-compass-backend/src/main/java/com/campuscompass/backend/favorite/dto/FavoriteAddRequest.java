package com.campuscompass.backend.favorite.dto;

import lombok.Getter;

@Getter
public class FavoriteAddRequest {
    private Integer roomId;
}