package com.campuscompass.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusCompassApplicationTests {

    @Test
    void contextLoads() {
    }

}
